 #include <iostream>
 #include <vector>
using namespace std;

// Function declaration
vector<int> addOne(vector<int> nos);

int main() {
    // Self-initialized vector
    vector<int> nos = {9,9,9};

    cout << "Initially nos contains: ";
    for (int i = 0; i < nos.size(); i++) {
        cout << nos[i] << " ";
    }

    // Add one to the number
    nos = addOne(nos);

    cout << "\n\nAfter adding 1, nos contains: ";
    for (int i = 0; i < nos.size(); i++) {
        cout << nos[i] << " ";
    }

    return 0;
}

// Function definition
vector<int> addOne(vector<int> nos) {
    // Addition is done from right to left
    for (int i = nos.size() - 1; i >= 0; i--) {

        // Case 1: Digit is not 9
        if (nos[i] != 9) {
            nos[i]++;
            return nos;
        }

        // Case 2: Digit is 9
        nos[i] = 0;
    }

    // If all digits are 9, create a larger vector
    vector<int> result(nos.size() + 1, 0);
    result[0] = 1;

    return result;
}


















    
